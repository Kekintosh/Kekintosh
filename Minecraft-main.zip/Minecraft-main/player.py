from camera import Camera
from settings import *
import glm

class Player(Camera):
    def __init__(self, app, position=PLAYER_POS, yaw=-90, pitch=0):
        super().__init__(position, yaw, pitch)
        self.app = app
        self.GODMODE = False
        
        # Physics for collision
        self.velocity = glm.vec3(0.0)
        self.on_ground = False
        self.jump_strength = 8.0
        self.gravity = -20.0
    
    def update(self):
        voxel_handler = self.app.scene.world.voxel_handler
        self.keyboard_control()
        self.mouse_control()
        
        if not self.GODMODE:
            self.apply_physics()
        super().update()
    
    def apply_physics(self):
        voxel_handler = self.app.scene.world.voxel_handler
        
        # Check if we're on ground before applying physics
        was_on_ground = self.on_ground
        self.on_ground = voxel_handler.check_ground_collision()
        
        # Only apply gravity if we're not on ground or if we're jumping
        if not self.on_ground or self.velocity.y > 0:
            self.velocity.y += self.gravity * self.app.delta_time
        elif self.on_ground and self.velocity.y <= 0:
            # If we're on ground and not jumping, keep Y velocity at 0
            self.velocity.y = 0
        
        # Calculate displacement
        displacement = self.velocity * self.app.delta_time
        new_position = self.position + displacement
        
        # Handle collision
        final_position = voxel_handler.collide(self.position, new_position)
        
        # If we hit something above us while jumping, stop upward movement
        if self.velocity.y > 0 and final_position.y <= self.position.y:
            self.velocity.y = 0
        
        # Double jump prevention: if we moved down significantly, we're no longer on ground
        if final_position.y < self.position.y - 0.1:
            self.on_ground = False
        
        self.position = final_position
    
    def handle_mouse_press(self, button):
        """Handle mouse press events from moderngl-window"""
        voxel_handler = self.app.scene.world.voxel_handler
        
        if button == 1:  # Left mouse button
            voxel_handler.remove_voxel()
            voxel_handler.interaction_mode = 0
        elif button == 2:  # Right mouse button
            voxel_handler.set_voxel()
            voxel_handler.interaction_mode = 1
    
    def handle_event(self, key, action, modifiers):
        """Handle keyboard events from moderngl-window"""
        # Toggle god mode with G key
        if key == self.app.wnd.keys.G and action == self.app.wnd.keys.ACTION_PRESS:
            self.GODMODE = not self.GODMODE
        
        # Add any other special key handling here if needed
    
    def mouse_control(self):
        mouse_dx = self.app.mouse_dx
        mouse_dy = self.app.mouse_dy
        
        # Reset mouse deltas after reading them
        self.app.mouse_dx = 0
        self.app.mouse_dy = 0
        
        if mouse_dx:
            self.rotate_yaw(delta_x=mouse_dx * MOUSE_SENSITIVITY)
        if mouse_dy:
            self.rotate_pitch(delta_y=-mouse_dy * MOUSE_SENSITIVITY)
    
    def keyboard_control(self):
        """Handle continuous keyboard input for movement"""
        keys = self.app.keys
        voxel_handler = self.app.scene.world.voxel_handler
        
        if self.GODMODE:
            PLAYER_SPEED = 15
        else:
            PLAYER_SPEED = 4.317
        
        speed = PLAYER_SPEED * self.app.delta_time
        move_dir = glm.vec3(0.0)
        forward_h = self.forward_horizontal
        right_h = self.right_horizontal
        
        # Movement using moderngl-window key constants
        w_pressed = self.app.wnd.keys.W in keys
        a_pressed = self.app.wnd.keys.A in keys
        s_pressed = self.app.wnd.keys.S in keys
        d_pressed = self.app.wnd.keys.D in keys
        
        # Calculate movement direction
        if w_pressed:
            if a_pressed:
                move_dir += glm.normalize(forward_h - right_h)
            elif d_pressed:
                move_dir += glm.normalize(forward_h + right_h)
            else:
                move_dir += forward_h
        elif s_pressed:
            if a_pressed:
                move_dir += glm.normalize(-forward_h - right_h)
            elif d_pressed:
                move_dir += glm.normalize(-forward_h + right_h)
            else:
                move_dir += -forward_h
        else:
            if d_pressed:
                move_dir += right_h
            if a_pressed:
                move_dir -= right_h
        
        # Normalize movement direction
        if glm.length(move_dir) > 0:
            move_dir = glm.normalize(move_dir)
        
        # Apply movement
        if self.GODMODE:
            self.position += move_dir * speed
            # God mode vertical movement
            if self.app.wnd.keys.E in keys:
                self.position += self.up * speed
            if self.app.wnd.keys.Q in keys:
                self.position -= self.up * speed
        else:
            # Normal physics-based movement
            self.velocity.x = move_dir.x * PLAYER_SPEED
            self.velocity.z = move_dir.z * PLAYER_SPEED
            
            # Jumping - strict ground check to prevent double jumping
            if self.app.wnd.keys.SPACE in keys and self.on_ground and self.velocity.y <= 0.1:
                self.velocity.y = self.jump_strength
                self.on_ground = False