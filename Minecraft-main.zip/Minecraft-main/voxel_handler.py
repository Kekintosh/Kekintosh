from settings import *
from meshes.chunk_mesh_builder import get_chunk_index
import glm


class VoxelHandler:
    def __init__(self, world):
        self.app = world.app
        self.chunks = world.chunks

        # ray casting result
        self.chunk = None
        self.voxel_id = None
        self.voxel_index = None
        self.voxel_local_pos = None
        self.voxel_world_pos = None
        self.voxel_normal = None
        
        self.interaction_mode = 0  # 0: remove voxel   1: add voxel
        self.new_voxel_id = DIRT

    def add_voxel(self):
        if self.voxel_id:
            # check voxel id along normal
            new_voxel_pos = self.voxel_world_pos + self.voxel_normal
            result = self.get_voxel_id(new_voxel_pos)
            
            # is the new place empty?
            if not result[0]:
                # Check if placing block would overlap with player
                if self.would_block_overlap_player(new_voxel_pos):
                    return  # Don't place block if it would overlap player
                    
                _, voxel_index, _, chunk = result
                chunk.voxels[voxel_index] = self.new_voxel_id
                chunk.mesh.rebuild()

                # was it an empty chunk
                if chunk.is_empty:
                    chunk.is_empty = False
                    
                # Rebuild adjacent chunks
                self.rebuild_adjacent_chunks_for_pos(new_voxel_pos)

    def would_block_overlap_player(self, block_pos):
        """Check if placing a block at block_pos would overlap with the player"""
        CAMERA_HEIGHT = 1.62
        player_camera_pos = self.app.player.position
        player_feet_pos = glm.vec3(player_camera_pos.x, player_camera_pos.y - CAMERA_HEIGHT, player_camera_pos.z)
        
        # Player dimensions
        player_width = 0.6
        player_height = 1.8
        
        # Block bounds
        block_min = glm.vec3(block_pos.x, block_pos.y, block_pos.z)
        block_max = glm.vec3(block_pos.x + 1, block_pos.y + 1, block_pos.z + 1)
        
        # Player bounds (feet position based)
        player_min = glm.vec3(
            player_feet_pos.x - player_width/2,
            player_feet_pos.y,
            player_feet_pos.z - player_width/2
        )
        player_max = glm.vec3(
            player_feet_pos.x + player_width/2,
            player_feet_pos.y + player_height,
            player_feet_pos.z + player_width/2
        )
        
        # Check for overlap
        return not (block_max.x <= player_min.x or block_min.x >= player_max.x or
                   block_max.y <= player_min.y or block_min.y >= player_max.y or
                   block_max.z <= player_min.z or block_min.z >= player_max.z)

    def check_collision_at_position(self, position):
        """Check if there's a voxel collision at the given position"""
        # Player dimensions - feet position is the base
        player_width = 0.6  # Slightly smaller than 1 block
        player_height = 1.8  # Player height
    
        # Check collision points around player's bounding box
        # Position is the FEET position, not camera position
        check_points = [
            # Bottom corners (feet level)
            glm.vec3(position.x - player_width/2, position.y + 0.1, position.z - player_width/2),
            glm.vec3(position.x + player_width/2, position.y + 0.1, position.z - player_width/2),
            glm.vec3(position.x - player_width/2, position.y + 0.1, position.z + player_width/2),
            glm.vec3(position.x + player_width/2, position.y + 0.1, position.z + player_width/2),
        
            # Head level
            glm.vec3(position.x - player_width/2, position.y + player_height - 0.1, position.z - player_width/2),
            glm.vec3(position.x + player_width/2, position.y + player_height - 0.1, position.z - player_width/2),
            glm.vec3(position.x - player_width/2, position.y + player_height - 0.1, position.z + player_width/2),
            glm.vec3(position.x + player_width/2, position.y + player_height - 0.1, position.z + player_width/2),
        
            # Middle level - more points for better detection
            glm.vec3(position.x, position.y + player_height/2, position.z),
            glm.vec3(position.x - player_width/2, position.y + player_height/2, position.z),
            glm.vec3(position.x + player_width/2, position.y + player_height/2, position.z),
            glm.vec3(position.x, position.y + player_height/2, position.z - player_width/2),
            glm.vec3(position.x, position.y + player_height/2, position.z + player_width/2),
        ]
    
        for point in check_points:
            voxel_pos = glm.ivec3(glm.floor(point))
            result = self.get_voxel_id(voxel_pos)
            if result[0]:  # If there's a voxel at this position
                return True, voxel_pos
    
        return False, None

    def handle_collision(self, old_feet_pos, new_feet_pos):
        """Handle collision detection and response - positions are FEET positions"""
        collision, collision_pos = self.check_collision_at_position(new_feet_pos)
    
        if not collision:
            return new_feet_pos  # No collision, movement is valid
    
        # There's a collision, try to slide along each axis
        final_feet_pos = glm.vec3(old_feet_pos)
    
        # Try X movement only
        test_pos = glm.vec3(new_feet_pos.x, old_feet_pos.y, old_feet_pos.z)
        collision_x, _ = self.check_collision_at_position(test_pos)
        if not collision_x:
            final_feet_pos.x = new_feet_pos.x
    
        # Try Z movement only
        test_pos = glm.vec3(final_feet_pos.x, old_feet_pos.y, new_feet_pos.z)
        collision_z, _ = self.check_collision_at_position(test_pos)
        if not collision_z:
            final_feet_pos.z = new_feet_pos.z
    
        # Try Y movement only (jumping/falling) - do this last to handle ground properly
        test_pos = glm.vec3(final_feet_pos.x, new_feet_pos.y, final_feet_pos.z)
        collision_y, collision_voxel_y = self.check_collision_at_position(test_pos)
        if not collision_y:
            final_feet_pos.y = new_feet_pos.y
        else:
            # Handle ground/ceiling collision
            if new_feet_pos.y < old_feet_pos.y:  # Falling
                # Land on top of the voxel - feet should be at voxel_top
                if collision_voxel_y is not None:
                    final_feet_pos.y = float(collision_voxel_y.y + 1.0)
                    # Set ground state
                    if hasattr(self.app.player, 'on_ground'):
                        self.app.player.on_ground = True
            else:  # Jumping up and hit ceiling
                # Head hit ceiling - feet should be lowered
                if collision_voxel_y is not None:
                    final_feet_pos.y = float(collision_voxel_y.y - 1.8)  # player height
        
            # Reset vertical velocity
            if hasattr(self.app.player, 'velocity'):
                self.app.player.velocity.y = 0
    
        return final_feet_pos

    def collide(self, old_position, new_position):
        """Main collision method - converts camera position to feet position"""
        # Convert camera positions to feet positions
        CAMERA_HEIGHT = 1.62  # Minecraft-like camera height
    
        old_feet_pos = glm.vec3(old_position.x, old_position.y - CAMERA_HEIGHT, old_position.z)
        new_feet_pos = glm.vec3(new_position.x, new_position.y - CAMERA_HEIGHT, new_position.z)
    
        # Handle collision with feet positions
        final_feet_pos = self.handle_collision(old_feet_pos, new_feet_pos)
    
        # Convert back to camera position
        final_camera_pos = glm.vec3(final_feet_pos.x, final_feet_pos.y + CAMERA_HEIGHT, final_feet_pos.z)
    
        return final_camera_pos

    def check_ground_collision(self):
        """Check if player is on ground"""
        CAMERA_HEIGHT = 1.62
        player_camera_pos = self.app.player.position
        player_feet_pos = glm.vec3(player_camera_pos.x, player_camera_pos.y - CAMERA_HEIGHT, player_camera_pos.z)
    
        # Check slightly below the feet
        ground_check_pos = glm.vec3(player_feet_pos.x, player_feet_pos.y - 0.1, player_feet_pos.z)
        collision, _ = self.check_collision_at_position(ground_check_pos)
        return collision

    def rebuild_adj_chunk(self, adj_voxel_pos):
        index = get_chunk_index(adj_voxel_pos)
        if index != -1:
            self.chunks[index].mesh.rebuild()

    def rebuild_adjacent_chunks(self):
        if self.voxel_local_pos is None or self.voxel_world_pos is None:
            return
            
        lx, ly, lz = self.voxel_local_pos
        wx, wy, wz = self.voxel_world_pos

        if lx == 0:
            self.rebuild_adj_chunk((wx - 1, wy, wz))
        elif lx == CHUNK_SIZE - 1:
            self.rebuild_adj_chunk((wx + 1, wy, wz))

        if ly == 0:
            self.rebuild_adj_chunk((wx, wy - 1, wz))
        elif ly == CHUNK_SIZE - 1:
            self.rebuild_adj_chunk((wx, wy + 1, wz))

        if lz == 0:
            self.rebuild_adj_chunk((wx, wy, wz - 1))
        elif lz == CHUNK_SIZE - 1:
            self.rebuild_adj_chunk((wx, wy, wz + 1))

    def rebuild_adjacent_chunks_for_pos(self, world_pos):
        """Rebuild adjacent chunks for a specific world position"""
        # Get chunk position
        chunk_pos = glm.ivec3(world_pos // CHUNK_SIZE)
        # Get local position within chunk
        local_pos = world_pos - chunk_pos * CHUNK_SIZE
        
        lx, ly, lz = local_pos
        wx, wy, wz = world_pos

        if lx == 0:
            self.rebuild_adj_chunk((wx - 1, wy, wz))
        elif lx == CHUNK_SIZE - 1:
            self.rebuild_adj_chunk((wx + 1, wy, wz))

        if ly == 0:
            self.rebuild_adj_chunk((wx, wy - 1, wz))
        elif ly == CHUNK_SIZE - 1:
            self.rebuild_adj_chunk((wx, wy + 1, wz))

        if lz == 0:
            self.rebuild_adj_chunk((wx, wy, wz - 1))
        elif lz == CHUNK_SIZE - 1:
            self.rebuild_adj_chunk((wx, wy, wz + 1))

    def remove_voxel(self):
        if self.voxel_id:
            self.chunk.voxels[self.voxel_index] = 0
            self.chunk.mesh.rebuild()
            self.rebuild_adjacent_chunks()
            
    def set_voxel(self):
        self.add_voxel()

    def update(self):
        self.ray_cast()

    def ray_cast(self):
        # start point
        x1, y1, z1 = self.app.player.position
        # end point
        x2, y2, z2 = self.app.player.position + self.app.player.forward * MAX_RAY_DIST

        current_voxel_pos = glm.ivec3(x1, y1, z1)
        self.voxel_id = 0
        self.voxel_normal = glm.ivec3(0)
        step_dir = -1

        dx = glm.sign(x2 - x1)
        delta_x = min(dx / (x2 - x1), 10000000.0) if dx != 0 else 10000000.0
        max_x = delta_x * (1.0 - glm.fract(x1)) if dx > 0 else delta_x * glm.fract(x1)

        dy = glm.sign(y2 - y1)
        delta_y = min(dy / (y2 - y1), 10000000.0) if dy != 0 else 10000000.0
        max_y = delta_y * (1.0 - glm.fract(y1)) if dy > 0 else delta_y * glm.fract(y1)

        dz = glm.sign(z2 - z1)
        delta_z = min(dz / (z2 - z1), 10000000.0) if dz != 0 else 10000000.0
        max_z = delta_z * (1.0 - glm.fract(z1)) if dz > 0 else delta_z * glm.fract(z1)

        while not (max_x > 1.0 and max_y > 1.0 and max_z > 1.0):

            result = self.get_voxel_id(voxel_world_pos=current_voxel_pos)
            if result[0]:
                self.voxel_id, self.voxel_index, self.voxel_local_pos, self.chunk = result
                self.voxel_world_pos = current_voxel_pos

                if step_dir == 0:
                    self.voxel_normal.x = -dx
                elif step_dir == 1:
                    self.voxel_normal.y = -dy
                else:
                    self.voxel_normal.z = -dz
                return True

            if max_x < max_y:
                if max_x < max_z:
                    current_voxel_pos.x += dx
                    max_x += delta_x
                    step_dir = 0
                else:
                    current_voxel_pos.z += dz
                    max_z += delta_z
                    step_dir = 2
            else:
                if max_y < max_z:
                    current_voxel_pos.y += dy
                    max_y += delta_y
                    step_dir = 1
                else:
                    current_voxel_pos.z += dz
                    max_z += delta_z
                    step_dir = 2
        return False

    def get_voxel_id(self, voxel_world_pos):
        cx, cy, cz = chunk_pos = voxel_world_pos / CHUNK_SIZE

        if 0 <= cx < WORLD_W and 0 <= cy < WORLD_H and 0 <= cz < WORLD_D:
            chunk_index = cx + WORLD_W * cz + WORLD_AREA * cy
            chunk = self.chunks[chunk_index]

            lx, ly, lz = voxel_local_pos = voxel_world_pos - chunk_pos * CHUNK_SIZE

            voxel_index = lx + CHUNK_SIZE * lz + CHUNK_AREA * ly
            voxel_id = chunk.voxels[voxel_index]

            return voxel_id, voxel_index, voxel_local_pos, chunk
        return 0, 0, 0, 0