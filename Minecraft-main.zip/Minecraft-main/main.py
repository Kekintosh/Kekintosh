import moderngl_window as mglw
import moderngl as mgl
import numpy as np
from settings import *
from shader_program import ShaderProgram
from scene import Scene
from player import Player
from textures import Textures
from voxel_handler import VoxelHandler
import world
from ui.menu_manager import MenuManager
import sys

class VoxelEngine(mglw.WindowConfig):
    gl_version = (MAJOR_VER, MINOR_VER)
    title = "Stepcraft"
    window_size = (int(WIN_RES.x), int(WIN_RES.y))
    aspect_ratio = None
    resizable = True
    resource_dir = '.'

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.ctx = self.wnd.ctx
        self.ctx.enable(flags=mgl.DEPTH_TEST | mgl.CULL_FACE | mgl.BLEND)
        self.ctx.gc_mode = 'auto'

        self.clock = None  # Will be handled by moderngl_window
        self.delta_time = 0
        self.time = 0
        self.last_time = 0

        self.is_running = True
        self.mouse_dx = 0
        self.mouse_dy = 0
        self.game_state = "menu"  # "menu", "settings", "playing"
        self.keys = set()

        # Initialize game components first
        self.on_init()

        # IMPORTANT: Start with mouse exclusivity OFF for menu interaction
        self.set_exclusive_mouse(False)

    def on_init(self):
        """Initialize all game components - matches original pygame structure"""
        self.textures = Textures(self)
        self.player = Player(self)
        self.shader_program = ShaderProgram(self)
        self.scene = Scene(self)
        
        # Initialize world/voxel handler if the scene depends on it
        # This was missing in the moderngl_window version
        if hasattr(self.scene, 'world') and self.scene.world is None:
            self.scene.world = world.World(self)
        
        # Initialize menu after shader_program is ready
        self.menu_manager = MenuManager(self)
        
        # Setup UI elements after everything is initialized
        self.setup_crosshair()

    @property
    def width(self):
        return self.wnd.buffer_width

    @property
    def height(self):
        return self.wnd.buffer_height

    def set_exclusive_mouse(self, value):
        self.wnd.mouse_exclusivity = value

    def setup_crosshair(self):
        # Simple shader for solid color rendering
        crosshair_vertex_shader = """
        #version 330 core
        in vec2 in_position;
        void main() {
            gl_Position = vec4(in_position, 0.0, 1.0);
        }
        """
    
        crosshair_fragment_shader = """
        #version 330 core
        uniform vec4 u_color;
        out vec4 fragColor;
        void main() {
            fragColor = u_color;
        }
        """
    
        # Create shader program
        self.crosshair_shader = self.ctx.program(
            vertex_shader=crosshair_vertex_shader,
            fragment_shader=crosshair_fragment_shader
        )
    
        # Simplified geometry
        size = 0.03  # relative to screen size
        thickness = size / 10
        vertices = np.array([
            # Horizontal line
            -size, -thickness,
             size, -thickness,
             size,  thickness,
            -size,  thickness,
        
            # Vertical line
            -thickness, -size,
             thickness, -size,
             thickness,  size,
            -thickness,  size
        ], dtype='f4')
    
        self.crosshair_vbo = self.ctx.buffer(vertices)
        self.crosshair_vao = self.ctx.vertex_array(
            self.crosshair_shader,
            [(self.crosshair_vbo, '2f', 'in_position')]
        )

    def render_crosshair(self):
        self.ctx.disable(mgl.DEPTH_TEST)
        self.crosshair_shader['u_color'] = (1.0, 1.0, 1.0, 0.8)  # White
        self.crosshair_vao.render(mgl.TRIANGLE_FAN, vertices=4)  # Horizontal
        self.crosshair_vao.render(mgl.TRIANGLE_FAN, vertices=4, first=4)  # Vertical
        self.ctx.enable(mgl.DEPTH_TEST)

    def update(self):
        """Update game state - matches original pygame structure"""
        if self.game_state == "playing":
            self.player.update()
            self.shader_program.update()
            self.scene.update()
        # Note: moderngl_window handles timing automatically

    def on_render(self, time: float, frame_time: float):
        """Render method for moderngl_window"""
        self.ctx.clear(color=BG_COLOR)
        self.delta_time = frame_time
        self.time = time
        
        if not self.is_running:
            self.wnd.close()
            return
        
        # Update game state
        self.update()
        
        if self.game_state == "playing":
            # Render the 3D scene first
            self.scene.render()
            self.render_crosshair()
            
            # IMPORTANT: Render UI elements on top
            # This was missing - we need to render menu_manager for in-game UI
            self.menu_manager.render(self.game_state)
            
        else:
            # Menu/Settings rendering
            self.ctx.clear(color=(0, 0, 0, 0))
            self.menu_manager.render(self.game_state)

    def on_key_event(self, key, action, modifiers):
        """Handle keyboard events"""
        if action == self.wnd.keys.ACTION_PRESS:
            self.keys.add(key)
            if key == self.wnd.keys.ESCAPE:
                if self.game_state == "playing":
                    # Close inventory if open, otherwise go to menu
                    if self.menu_manager.inventory_open:
                        self.menu_manager.toggle_inventory()
                    else:
                        self.game_state = "menu"
                        self.set_exclusive_mouse(False)
                elif self.game_state == "settings":
                    self.game_state = "menu"
                else:
                    self.is_running = False
            elif key == self.wnd.keys.ENTER and self.game_state == "menu":
                self.game_state = "playing"
                self.set_exclusive_mouse(True)
            elif key == self.wnd.keys.TAB:
                # Let menu manager handle inventory toggle
                self.menu_manager.handle_key_press(key)
                
        elif action == self.wnd.keys.ACTION_RELEASE:
            if key in self.keys:
                self.keys.remove(key)
        
        # Pass events to player when in game (and inventory is closed)
        if self.game_state == "playing" and not self.menu_manager.inventory_open:
            self.player.handle_event(key, action, modifiers)

    def on_mouse_position_event(self, x, y, dx, dy):
        """Handle mouse movement"""
        if self.game_state == "playing" and not self.menu_manager.inventory_open:
            self.mouse_dx = dx
            self.mouse_dy = -dy

    def on_mouse_press_event(self, x, y, button):
        """Handle mouse press events"""
        if self.game_state == "playing":
            if self.menu_manager.inventory_open:
                # Handle inventory clicks (you can add inventory slot logic here)
                pass
            else:
                self.player.handle_mouse_press(button)
        else:
            result = self.menu_manager.handle_mouse_press(x, y, button)
            if result == "singleplayer":
                self.game_state = "playing"
                self.set_exclusive_mouse(True)
            elif result == "settings":
                self.game_state = "settings"
            elif result == "quit":
                self.is_running = False

    def on_mouse_release_event(self, x, y, button):
        """Handle mouse release events"""
        if self.game_state != "playing":
            self.menu_manager.handle_mouse_release(x, y, button)

if __name__ == '__main__':
    mglw.run_window_config(VoxelEngine)