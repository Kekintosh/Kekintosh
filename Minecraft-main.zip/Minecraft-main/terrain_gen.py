from noise import noise2, noise3
from random import random, randint
from settings import *
import math

@njit
def get_height(x, z):
    # island mask
    island = 1 / (pow(0.0025 * math.hypot(x - CENTER_XZ, z - CENTER_XZ), 20) + 0.0001)
    island = min(island, 1)
    # amplitude
    a1 = CENTER_Y - TERRAIN_OFFSET  # Adjust amplitude for new offset
    a2, a4, a8 = a1 * 0.5, a1 * 0.25, a1 * 0.125
    # frequency
    f1 = 0.005
    f2, f4, f8 = f1 * 2, f1 * 4, f1 * 8
    if noise2(0.1 * x, 0.1 * z) < 0:
        a1 /= 1.07
    height = 0
    height += noise2(x * f1, z * f1) * a1 + a1
    height += noise2(x * f2, z * f2) * a2 - a2
    height += noise2(x * f4, z * f4) * a4 + a4
    height += noise2(x * f8, z * f8) * a8 - a8
    height = max(height, noise2(x * f8, z * f8) + 2)
    height *= island
    return int(height + TERRAIN_OFFSET)  # Add terrain offset to move everything up

@njit
def get_index(x, y, z):
    return x + CHUNK_SIZE * z + CHUNK_AREA * y

# Enhanced cave generation with better distribution
@njit
def is_cave(wx, wy, wz):
    # Don't generate caves too close to surface or bedrock
    if wy <= 5 or wy >= TERRAIN_OFFSET - 3:
        return False
    
    # Multi-octave cave generation for more realistic caves
    cave_noise1 = noise3(wx * 0.02, wy * 0.02, wz * 0.02)  # Large caverns
    cave_noise2 = noise3(wx * 0.08, wy * 0.08, wz * 0.08)  # Tunnels
    cave_noise3 = noise3(wx * 0.15, wy * 0.15, wz * 0.15)  # Small pockets
    
    # Combine noises for complex cave systems
    cave_density = cave_noise1 * 0.6 + cave_noise2 * 0.3 + cave_noise3 * 0.1
    
    # Height-based cave probability (more caves at certain depths)
    depth_factor = 1.0
    if 15 <= wy <= 35:  # Prime cave depth
        depth_factor = 1.2
    elif wy <= 10:  # Deep caves
        depth_factor = 0.8
    
    return cave_density > (0.35 / depth_factor)

# Enhanced cave generation for mountains
@njit
def is_mountain_cave(wx, wy, wz, surface_height):
    # Only generate in mountain areas (above terrain offset)
    if wy <= TERRAIN_OFFSET or wy >= surface_height - 3:
        return False
    
    # Mountain-specific cave generation
    mountain_caves = noise3(wx * 0.05, wy * 0.05, wz * 0.05)
    tunnel_caves = noise3(wx * 0.12, wy * 0.08, wz * 0.12)
    
    # Combine for mountain cave systems
    cave_value = mountain_caves * 0.7 + tunnel_caves * 0.3
    
    # Higher threshold for mountain caves (less common but larger)
    return cave_value > 0.45

# Cave culling - only render caves that have adjacent non-cave blocks
@njit
def should_render_cave(voxels, x, y, z):
    """Check if a cave voxel should be rendered based on adjacent blocks"""
    if x < 0 or x >= CHUNK_SIZE or y < 0 or y >= CHUNK_SIZE or z < 0 or z >= CHUNK_SIZE:
        return False
    
    current_idx = get_index(x, y, z)
    if voxels[current_idx] != 0:  # Not a cave
        return False
    
    # Check all 6 adjacent faces
    adjacent_positions = [
        (x + 1, y, z), (x - 1, y, z),  # X faces
        (x, y + 1, z), (x, y - 1, z),  # Y faces
        (x, y, z + 1), (x, y, z - 1)   # Z faces
    ]
    
    for ax, ay, az in adjacent_positions:
        # Check bounds
        if 0 <= ax < CHUNK_SIZE and 0 <= ay < CHUNK_SIZE and 0 <= az < CHUNK_SIZE:
            adj_idx = get_index(ax, ay, az)
            if voxels[adj_idx] != 0:  # Adjacent to solid block
                return True
        else:
            # If adjacent to chunk boundary, assume it should be rendered
            return True
    
    return False

# Optimized voxel check with mountain cave support
@njit
def get_voxel_id(wx, wy, wz, world_height):
    # Fast bedrock check
    if wy <= 0:
        return BEDROCK
    elif wy <= 4:
        # Simple bedrock pattern
        if noise2(wx * 0.1, wz * 0.1) > 0.2:
            return BEDROCK
        return STONE
    elif wy <= 10:
        # Lava layer
        if noise3(wx * 0.1, wy * 0.1, wz * 0.1) > 0.4:
            return LAVA
        return STONE
    elif wy < TERRAIN_OFFSET:
        # Underground - check caves first
        if is_cave(wx, wy, wz):
            return 0
        return STONE
    elif wy < world_height - 1:
        # Below surface terrain - check both underground and mountain caves
        if is_cave(wx, wy, wz) or is_mountain_cave(wx, wy, wz, world_height):
            return 0
        return STONE
    else:
        # Surface terrain - simplified
        if wy >= SNOW_LVL:
            return SNOW
        elif wy >= STONE_LVL:
            return STONE
        elif wy >= DIRT_LVL:
            return DIRT
        elif wy >= GRASS_LVL:
            return GRASS
        else:
            return SAND

# Minecraft-accurate tree generation
@njit
def place_tree(voxels, x, y, z, voxel_id):
    rnd = random()
    if voxel_id != GRASS or rnd > TREE_PROBABILITY:
        return None
    
    # Random tree height (5-7 blocks like Minecraft oak trees)
    tree_height = randint(5, 7)
    
    # Check if tree can fit
    if y + tree_height + 3 >= CHUNK_SIZE:  # +3 for leaves above trunk
        return None
    if x < 2 or x >= CHUNK_SIZE - 2:  # Safe boundary check
        return None
    if z < 2 or z >= CHUNK_SIZE - 2:
        return None
    
    # Change grass to dirt under tree
    voxels[get_index(x, y, z)] = DIRT
    
    # Build trunk
    for trunk_y in range(1, tree_height):
        trunk_idx = get_index(x, y + trunk_y, z)
        voxels[trunk_idx] = WOOD
    
    # Generate leaves (Minecraft oak tree pattern)
    # Layer 1: Top of tree (1 block above trunk)
    top_y = y + tree_height
    if top_y < CHUNK_SIZE:
        voxels[get_index(x, top_y, z)] = LEAVES
    
    # Layer 2: Cross pattern at trunk top
    leaf_positions_top = [
        (x, y + tree_height - 1, z),      # Center (replace trunk top)
        (x + 1, y + tree_height - 1, z),  # North
        (x - 1, y + tree_height - 1, z),  # South
        (x, y + tree_height - 1, z + 1),  # East
        (x, y + tree_height - 1, z - 1),  # West
    ]
    
    for lx, ly, lz in leaf_positions_top:
        if 0 <= lx < CHUNK_SIZE and 0 <= ly < CHUNK_SIZE and 0 <= lz < CHUNK_SIZE:
            voxels[get_index(lx, ly, lz)] = LEAVES
    
    # Layer 3 & 4: Full 5x5 leaf layers (like Minecraft)
    for layer_offset in range(2, 4):  # 2 layers
        leaf_y = y + tree_height - layer_offset
        if leaf_y < CHUNK_SIZE:
            for dx in range(-2, 3):
                for dz in range(-2, 3):
                    lx, lz = x + dx, z + dz
                    
                    # Skip corners for more natural look
                    if abs(dx) == 2 and abs(dz) == 2:
                        continue
                    
                    # Skip center on lower layer (trunk goes through)
                    if layer_offset == 2 and dx == 0 and dz == 0:
                        continue
                    
                    if 0 <= lx < CHUNK_SIZE and 0 <= lz < CHUNK_SIZE:
                        voxels[get_index(lx, leaf_y, lz)] = LEAVES
    
    # Additional random leaves for natural variation
    if random() < 0.3:  # 30% chance for extra leaves
        for _ in range(randint(1, 3)):
            extra_x = x + randint(-2, 2)
            extra_z = z + randint(-2, 2)
            extra_y = y + max(1, tree_height - randint(1, 3))  # Ensure positive range
            
            if (0 <= extra_x < CHUNK_SIZE and 0 <= extra_z < CHUNK_SIZE and 
                0 <= extra_y < CHUNK_SIZE):
                extra_idx = get_index(extra_x, extra_y, extra_z)
                if voxels[extra_idx] == 0:  # Only place if air
                    voxels[extra_idx] = LEAVES

# Enhanced cave entrance generation
@njit
def create_surface_cave_entrances(voxels, chunk_x, chunk_z):
    # Create more natural cave entrances
    for _ in range(randint(0, 3)):  # 0-3 entrances per chunk
        if random() < 0.70:  # 20% chance
            # Safe boundary checks
            min_x = max(8, 0)
            max_x = min(CHUNK_SIZE - 9, CHUNK_SIZE - 1)
            min_z = max(8, 0)
            max_z = min(CHUNK_SIZE - 9, CHUNK_SIZE - 1)
            
            if min_x >= max_x or min_z >= max_z:
                continue  # Skip if invalid range
                
            x = randint(min_x, max_x)
            z = randint(min_z, max_z)
            
            # Get world coordinates
            wx = chunk_x * CHUNK_SIZE + x
            wz = chunk_z * CHUNK_SIZE + z
            world_height = get_height(wx, wz)
            
            # Find actual surface in chunk
            surface_y = -1
            for y in range(CHUNK_SIZE - 1, -1, -1):
                idx = get_index(x, y, z)
                if voxels[idx] != 0:
                    surface_y = y
                    break
            
            # Only create entrance if surface is above terrain offset
            if surface_y > TERRAIN_OFFSET + 10:
                entrance_depth = randint(15, min(25, surface_y - 5))
                entrance_width = randint(3, 5)
                
                # Create entrance with natural shape
                for dy in range(min(entrance_depth, surface_y)):
                    current_y = surface_y - dy
                    if current_y <= 0:
                        break
                    
                    # Gradually reduce width as we go down
                    current_width = max(1, entrance_width - dy // 4)
                    
                    for dx in range(-current_width, current_width + 1):
                        for dz in range(-current_width, current_width + 1):
                            entrance_x = x + dx
                            entrance_z = z + dz
                            
                            if (0 <= entrance_x < CHUNK_SIZE and 0 <= entrance_z < CHUNK_SIZE):
                                # Create more natural circular entrance
                                distance = math.sqrt(dx*dx + dz*dz)
                                if distance <= current_width:
                                    # Add some randomness for natural look
                                    if random() < 0.8 or distance <= current_width * 0.6:
                                        idx = get_index(entrance_x, current_y, entrance_z)
                                        voxels[idx] = 0
                                        
                                        # Add some decorative blocks around entrance
                                        if dy < 3 and distance > current_width * 0.7:
                                            if random() < 0.3:
                                                voxels[idx] = STONE

# Cave entrance on cliff faces
@njit
def create_cliff_cave_entrances(voxels, chunk_x, chunk_z):
    # Look for steep terrain changes for cliff entrances
    for _ in range(randint(4, 12)):
        if random() < 0.90:  # 15% chance
            # Safe boundary checks
            min_pos = max(5, 0)
            max_pos = min(CHUNK_SIZE - 6, CHUNK_SIZE - 1)
            
            if min_pos >= max_pos:
                continue  # Skip if invalid range
                
            x = randint(min_pos, max_pos)
            z = randint(min_pos, max_pos)
            
            # Check for steep terrain (cliff face)
            steep_found = False
            for check_x in range(x - 2, x + 3):
                for check_z in range(z - 2, z + 3):
                    if 0 <= check_x < CHUNK_SIZE and 0 <= check_z < CHUNK_SIZE:
                        # Get height difference
                        wx1 = chunk_x * CHUNK_SIZE + check_x
                        wz1 = chunk_z * CHUNK_SIZE + check_z
                        wx2 = wx1 + 1
                        wz2 = wz1 + 1
                        
                        height1 = get_height(wx1, wz1)
                        height2 = get_height(wx2, wz2)
                        
                        if abs(height1 - height2) > 8:  # Steep enough
                            steep_found = True
                            break
                if steep_found:
                    break
            
            if steep_found:
                # Create horizontal cave entrance
                min_entrance_y = max(TERRAIN_OFFSET + 5, 0)
                max_entrance_y = min(CHUNK_SIZE - 10, CHUNK_SIZE - 1)
                
                if min_entrance_y >= max_entrance_y:
                    continue  # Skip if invalid range
                    
                entrance_y = randint(min_entrance_y, max_entrance_y)
                entrance_width = randint(2, 4)
                entrance_depth = randint(8, 15)
                
                for dd in range(entrance_depth):
                    for dx in range(-entrance_width//2, entrance_width//2 + 1):
                        for dy in range(-entrance_width//2, entrance_width//2 + 1):
                            entrance_x = x + dd
                            entrance_y_pos = entrance_y + dy
                            entrance_z = z + dx
                            
                            if (0 <= entrance_x < CHUNK_SIZE and 
                                0 <= entrance_y_pos < CHUNK_SIZE and 
                                0 <= entrance_z < CHUNK_SIZE):
                                
                                distance = math.sqrt(dx*dx + dy*dy)
                                if distance <= entrance_width/2:
                                    idx = get_index(entrance_x, entrance_y_pos, entrance_z)
                                    voxels[idx] = 0

# Ore blob generation - same as before but optimized
@njit
def generate_ore_blob(voxels, center_x, center_y, center_z, ore_type, size):
    # Simplified ellipsoid
    radius = size * 0.75
    
    # Generate blocks in sphere
    for x in range(int(center_x - radius), int(center_x + radius + 1)):
        for y in range(int(center_y - radius), int(center_y + radius + 1)):
            for z in range(int(center_z - radius), int(center_z + radius + 1)):
                # Check bounds
                if (x < 0 or x >= CHUNK_SIZE or 
                    y < 0 or y >= CHUNK_SIZE or 
                    z < 0 or z >= CHUNK_SIZE):
                    continue
                
                # Simple distance check
                dist_sq = (x - center_x)**2 + (y - center_y)**2 + (z - center_z)**2
                if dist_sq <= radius**2 and random() < 0.8:
                    idx = get_index(x, y, z)
                    # Only replace stone
                    if voxels[idx] == STONE:
                        voxels[idx] = ore_type

# Optimized ore generation - fewer checks
@njit
def generate_chunk_ores(voxels):
    # Coal - most common
    for _ in range(randint(9, 16)):
        if random() < 0.9:
            x = randint(2, CHUNK_SIZE - 3)
            y = randint(1, 55)
            z = randint(2, CHUNK_SIZE - 3)
            generate_ore_blob(voxels, x, y, z, COAL_ORE, randint(1, 2))
    
    # Iron
    for _ in range(randint(6, 15)):
        if random() < 0.7:
            x = randint(2, CHUNK_SIZE - 3)
            y = randint(1, 45)
            z = randint(2, CHUNK_SIZE - 3)
            generate_ore_blob(voxels, x, y, z, IRON_ORE, randint(1, 2))
    
    # Gold
    for _ in range(randint(5, 16)):
        if random() < 0.5:
            x = randint(2, CHUNK_SIZE - 3)
            y = randint(1, 25)
            z = randint(2, CHUNK_SIZE - 3)
            generate_ore_blob(voxels, x, y, z, GOLD_ORE, randint(1, 2))
    #LAPIS LAZULI
    for _ in range(randint(3, 16)):
        if random() < 0.25:
            x = randint(2, CHUNK_SIZE - 3)
            y = randint(1, 25)
            z = randint(2, CHUNK_SIZE - 3)
            generate_ore_blob(voxels, x, y, z, LAPIS_ORE, randint(1, 2))
    
    # Diamond
    if random() < 0.3:
        x = randint(2, CHUNK_SIZE - 3)
        y = randint(1, 15)
        z = randint(2, CHUNK_SIZE - 3)
        generate_ore_blob(voxels, x, y, z, DIAMOND_ORE, randint(1, 2))

# Main optimized terrain generation
@njit
def set_voxel_id(voxels, x, y, z, wx, wy, wz, world_height):
    # Get voxel type
    voxel_id = get_voxel_id(wx, wy, wz, world_height)
    
    # Set voxel
    voxels[get_index(x, y, z)] = voxel_id
    
    # Place tree only on grass surface
    if voxel_id == GRASS and wy >= world_height - 1:
        place_tree(voxels, x, y, z, voxel_id)

# Call this function AFTER generating all terrain for the chunk
@njit
def generate_chunk_complete(voxels, chunk_x, chunk_z, world_height):
    # Generate ore blobs after terrain generation
    generate_chunk_ores(voxels)
    
    # Create natural cave entrances
    create_surface_cave_entrances(voxels, chunk_x, chunk_z)
    
    # Create cliff cave entrances
    create_cliff_cave_entrances(voxels, chunk_x, chunk_z)

# Cave culling optimization for rendering
@njit
def get_renderable_caves(voxels):
    """Returns array of cave positions that should be rendered"""
    renderable_caves = []
    
    for x in range(CHUNK_SIZE):
        for y in range(CHUNK_SIZE):
            for z in range(CHUNK_SIZE):
                if should_render_cave(voxels, x, y, z):
                    renderable_caves.append((x, y, z))
    
    return renderable_caves