from settings import *
from frustum import Frustum
import glm

class Camera:
    def __init__(self, position, yaw, pitch):
        self.position = glm.vec3(position)
        self.yaw = glm.radians(yaw)
        self.pitch = glm.radians(pitch)
        self.up = glm.vec3(0, 1, 0)
        self.right = glm.vec3(1, 0, 0)
        self.forward = glm.vec3(0, 0, -1)
        # Horizontal movement vectors (ignore pitch)
        self.forward_horizontal = glm.vec3(0, 0, -1)
        self.right_horizontal = glm.vec3(1, 0, 0)
        
        self.m_proj = glm.perspective(V_FOV, ASPECT_RATIO, NEAR, FAR)
        self.m_view = glm.mat4()
        self.frustum = Frustum(self)
    
    def update(self):
        self.update_vectors()
        self.update_view_matrix()
    
    def update_view_matrix(self):
        self.m_view = glm.lookAt(self.position, self.position + self.forward, self.up)
    
    def update_vectors(self):
        # Full forward vector (for looking/view matrix)
        self.forward.x = glm.cos(self.yaw) * glm.cos(self.pitch)
        self.forward.y = glm.sin(self.pitch)
        self.forward.z = glm.sin(self.yaw) * glm.cos(self.pitch)
        self.forward = glm.normalize(self.forward)
        
        # Horizontal-only vectors (for movement, ignore pitch)
        self.forward_horizontal.x = glm.cos(self.yaw)
        self.forward_horizontal.y = 0  # Keep Y at 0 for horizontal movement
        self.forward_horizontal.z = glm.sin(self.yaw)
        self.forward_horizontal = glm.normalize(self.forward_horizontal)
        
        # Right vector based on horizontal forward
        self.right_horizontal = glm.normalize(glm.cross(self.forward_horizontal, glm.vec3(0, 1, 0)))
        
        # Regular right vector for view calculations
        self.right = glm.normalize(glm.cross(self.forward, glm.vec3(0, 1, 0)))
    
    def rotate_pitch(self, delta_y):
        self.pitch -= delta_y
        self.pitch = glm.clamp(self.pitch, -PITCH_MAX, PITCH_MAX)
    
    def rotate_yaw(self, delta_x):
        self.yaw += delta_x
    
    # Fixed movement functions using horizontal vectors
    def move_left(self, velocity):
        self.position -= self.right_horizontal * velocity
    
    def move_right(self, velocity):
        self.position += self.right_horizontal * velocity
    
    def move_up(self, velocity):
        self.position += self.up * velocity
    
    def move_down(self, velocity):
        self.position -= self.up * velocity
    
    def move_forward(self, velocity):
        self.position += self.forward_horizontal * velocity
    
    def move_back(self, velocity):
        self.position -= self.forward_horizontal * velocity
    
    def move_forward_left(self, velocity):
        dir = glm.normalize(self.forward_horizontal - self.right_horizontal)
        self.position += dir * velocity
    
    def move_forward_right(self, velocity):
        dir = glm.normalize(self.forward_horizontal + self.right_horizontal)
        self.position += dir * velocity
    
    def move_back_left(self, velocity):
        dir = glm.normalize(-self.forward_horizontal - self.right_horizontal)
        self.position += dir * velocity
    
    def move_back_right(self, velocity):
        dir = glm.normalize(-self.forward_horizontal + self.right_horizontal)
        self.position += dir * velocity