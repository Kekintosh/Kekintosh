from numba import njit
import numpy as np
import glm
import math

# OpenGL settings
MAJOR_VER, MINOR_VER = 3, 3
DEPTH_SIZE = 24
NUM_SAMPLES = 1  # antialiasing 1 org
# resolution
WIN_RES = glm.vec2(800, 600)
# world generation
SEED = 16
# ray casting
MAX_RAY_DIST = 6
# chunk
CHUNK_SIZE = 40 # org?
H_CHUNK_SIZE = CHUNK_SIZE // 2
CHUNK_AREA = CHUNK_SIZE * CHUNK_SIZE
CHUNK_VOL = CHUNK_AREA * CHUNK_SIZE
CHUNK_SPHERE_RADIUS = H_CHUNK_SIZE * math.sqrt(3)
# world
WORLD_W, WORLD_H = 20, 3 # Keep your existing world dimensions
WORLD_D = WORLD_W
WORLD_AREA = WORLD_W * WORLD_D
WORLD_VOL = WORLD_AREA * WORLD_H
# world center - adjusted for new terrain height
CENTER_XZ = WORLD_W * H_CHUNK_SIZE
CENTER_Y = 64 + (WORLD_H * H_CHUNK_SIZE)  # Terrain now starts at y=64
# camera
ASPECT_RATIO = WIN_RES.x / WIN_RES.y
FOV_DEG = 100
V_FOV = glm.radians(FOV_DEG)  # vertical FOV
H_FOV = 2 * math.atan(math.tan(V_FOV * 0.5) * ASPECT_RATIO)  # horizontal FOV
NEAR = 0.1
FAR = 1000.0
PITCH_MAX = glm.radians(89)
# player - adjusted spawn position
PLAYER_SPEED = 4.317
PLAYER_ROT_SPEED = 0.003
PLAYER_POS = glm.vec3(CENTER_XZ, 100 + CHUNK_SIZE, CENTER_XZ)  # Spawn above new terrain level
MOUSE_SENSITIVITY = 0.003
# colors
BG_COLOR = glm.vec3(0.58, 0.83, 0.99)
# textures
SAND = 1
GRASS = 2
DIRT = 3
STONE = 4
SNOW = 5
LEAVES = 6
WOOD = 7
BEDROCK = 8
DIAMOND_ORE = 9 
LAPIS_ORE = 10
GOLD_ORE = 11
IRON_ORE = 12
COAL_ORE = 13
LAVA = 14
WATER = 15  
# terrain levels - adjusted to start from y=64
TERRAIN_OFFSET = 64  # New base level for terrain
SNOW_LVL = TERRAIN_OFFSET + 54
STONE_LVL = TERRAIN_OFFSET + 49
DIRT_LVL = TERRAIN_OFFSET + 48
GRASS_LVL = TERRAIN_OFFSET + 8
SAND_LVL = TERRAIN_OFFSET + 7
# tree settings
TREE_PROBABILITY = 0.02 # 0.02 org
TREE_WIDTH, TREE_HEIGHT = 4, 6
TREE_H_WIDTH, TREE_H_HEIGHT = 5, 4
# water
WATER_LINE = TERRAIN_OFFSET + 5.6
WATER_AREA = 5 * CHUNK_SIZE * WORLD_W
# cloud
CLOUD_SCALE = 25
CLOUD_HEIGHT = TERRAIN_OFFSET + 100