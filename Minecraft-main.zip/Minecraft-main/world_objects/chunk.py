from settings import *
from meshes.chunk_mesh import ChunkMesh
import random
from terrain_gen import *

class Chunk:
    def __init__(self, world, position):
        self.app = world.app
        self.world = world
        self.position = position
        self.m_model = self.get_model_matrix()
        self.voxels: np.array = None
        self.mesh: ChunkMesh = None
        self.is_empty = True
        self.center = (glm.vec3(self.position) + 0.5) * CHUNK_SIZE
        self.is_on_frustum = self.app.player.frustum.is_on_frustum

    def get_model_matrix(self):
        m_model = glm.translate(glm.mat4(), glm.vec3(self.position) * CHUNK_SIZE)
        return m_model

    def set_uniform(self):
        self.mesh.program['m_model'].write(self.m_model)

    def build_mesh(self):
        self.mesh = ChunkMesh(self)

    def render(self):
        if not self.is_empty and self.is_on_frustum(self):
            self.set_uniform()
            self.mesh.render()

    def build_voxels(self):
        voxels = np.zeros(CHUNK_VOL, dtype='uint8')
        cx, cy, cz = glm.ivec3(self.position) * CHUNK_SIZE
        
        # Step 1: Generate all terrain first
        self.generate_terrain(voxels, cx, cy, cz)
        
        # Step 2: Generate ores AFTER terrain is complete
        # Only generate ores if this chunk contains underground stone
        if cy < 100:  # Adjust this based on your world height
            # Calculate average world height for this chunk
            world_height = 0
            sample_count = 0
            for x in range(0, CHUNK_SIZE, 4):  # Sample every 4 blocks
                for z in range(0, CHUNK_SIZE, 4):
                    wx = x + cx
                    wz = z + cz
                    world_height += get_height(wx, wz)
                    sample_count += 1
            avg_world_height = max(20, world_height / sample_count)  # Ensure minimum height
            
            # Generate ore blobs for this chunk
            generate_chunk_complete(voxels, cx // CHUNK_SIZE, cz // CHUNK_SIZE, int(avg_world_height))
            
        if np.any(voxels):
            self.is_empty = False
        return voxels

    @staticmethod
    @njit
    def generate_terrain(voxels, cx, cy, cz):
        underground_depth = 64  # Deep underground like Minecraft
        
        for x in range(CHUNK_SIZE):
            wx = x + cx
            for z in range(CHUNK_SIZE):
                wz = z + cz
                world_height = get_height(wx, wz)
                
                # Generate from bedrock level to surface
                # Extend downward by underground_depth
                min_y = max(0, -underground_depth - cy)
                max_y = min(CHUNK_SIZE, world_height - cy)
                
                for y in range(min_y, max_y):
                    wy = y + cy
                    set_voxel_id(voxels, x, y, z, wx, wy, wz, world_height)