import numpy as np
from PIL import Image, ImageDraw, ImageFont
from .textured_button import TexturedButton

class MenuManager:
    def __init__(self, app):
        self.app = app
        self.ctx = app.ctx
        self.setup_shader()
        self.load_background()
        self.create_logo_button()
        self.create_main_menu()
        self.create_settings_menu()
        
        # Inventory system
        self.inventory_open = False
        self.setup_inventory()
        self.setup_hotbar()

    def setup_shader(self):
        vertex_shader = '''
            #version 330 core
            in vec2 in_position;
            in vec2 in_texcoord;
            out vec2 uv;
            void main() {
                gl_Position = vec4(in_position, 0.0, 1.0);
                uv = in_texcoord;
            }
        '''
        fragment_shader = '''
            #version 330 core
            uniform sampler2D u_texture;
            uniform vec4 u_color;
            in vec2 uv;
            out vec4 fragColor;
            void main() {
                vec4 tex_color = texture(u_texture, uv);
                fragColor = tex_color * u_color;
            }
        '''
        self.shader = self.ctx.program(
            vertex_shader=vertex_shader,
            fragment_shader=fragment_shader
        )

    def load_background(self):
        bg_img = Image.open('assets/0.jpg').convert('RGBA').transpose(Image.FLIP_TOP_BOTTOM)
        self.bg_texture = self.ctx.texture(bg_img.size, 4, bg_img.tobytes())
        self.bg_texture.build_mipmaps()
        self.bg_texture.filter = (self.ctx.NEAREST, self.ctx.NEAREST)
        w, h = self.app.width, self.app.height
        vertices = np.array([
            -1, -1, 0, 0,
            1, -1, 1, 0,
            1, 1, 1, 1,
            -1, -1, 0, 0,
            1, 1, 1, 1,
            -1, 1, 0, 1
        ], dtype=np.float32)
        self.bg_vbo = self.ctx.buffer(vertices.tobytes())
        self.bg_vao = self.ctx.vertex_array(self.shader, [(self.bg_vbo, '2f 2f', 'in_position', 'in_texcoord')])

    def setup_inventory(self):
        """Setup inventory UI quad"""
        # Inventory dimensions (similar to Minecraft)
        self.inventory_width = 352  # 9 slots * 36px + padding
        self.inventory_height = 332  # Multiple rows + crafting area
        
        # Center the inventory on screen
        inv_x = (self.app.width - self.inventory_width) // 2
        inv_y = (self.app.height - self.inventory_height) // 2
        
        # Convert to normalized coordinates for OpenGL
        left = (inv_x / self.app.width) * 2 - 1
        right = ((inv_x + self.inventory_width) / self.app.width) * 2 - 1
        bottom = (inv_y / self.app.height) * 2 - 1
        top = ((inv_y + self.inventory_height) / self.app.height) * 2 - 1
        
        # Create inventory quad vertices
        inventory_vertices = np.array([
            left, bottom, 0, 0,    # bottom-left
            right, bottom, 1, 0,   # bottom-right
            right, top, 1, 1,      # top-right
            left, bottom, 0, 0,    # bottom-left
            right, top, 1, 1,      # top-right
            left, top, 0, 1        # top-left
        ], dtype=np.float32)
        
        self.inventory_vbo = self.ctx.buffer(inventory_vertices.tobytes())
        self.inventory_vao = self.ctx.vertex_array(self.shader, [(self.inventory_vbo, '2f 2f', 'in_position', 'in_texcoord')])
        
        # Use texture for inventory background (you can change this to your inventory texture)
        self.inventory_texture = self.app.textures.texture_7  # Replace with your inventory texture

    def setup_hotbar(self):
        """Setup hotbar UI at bottom of screen"""
        # Hotbar dimensions (9 slots like Minecraft)
        self.hotbar_width = 364  # 9 slots * 40px + padding
        self.hotbar_height = 44
        
        # Position at bottom center of screen
        hotbar_x = (self.app.width - self.hotbar_width) // 2
        hotbar_y = 0  # 20px from bottom
        
        # Convert to normalized coordinates for OpenGL
        left = (hotbar_x / self.app.width) * 2 - 1
        right = ((hotbar_x + self.hotbar_width) / self.app.width) * 2 - 1
        bottom = (hotbar_y / self.app.height) * 2 - 1
        top = ((hotbar_y + self.hotbar_height) / self.app.height) * 2 - 1
        
        # Create hotbar quad vertices
        hotbar_vertices = np.array([
            left, bottom, 0, 0,    # bottom-left
            right, bottom, 1, 0,   # bottom-right
            right, top, 1, 1,      # top-right
            left, bottom, 0, 0,    # bottom-left
            right, top, 1, 1,      # top-right
            left, top, 0, 1        # top-left
        ], dtype=np.float32)
        
        self.hotbar_vbo = self.ctx.buffer(hotbar_vertices.tobytes())
        self.hotbar_vao = self.ctx.vertex_array(self.shader, [(self.hotbar_vbo, '2f 2f', 'in_position', 'in_texcoord')])
        
        # Use texture for hotbar background (you can change this to your hotbar texture)
        self.hotbar_texture = self.app.textures.texture_6  # Replace with your hotbar texture

    def create_logo_button(self):
        # Use a big button for the logo (not clickable)
        logo_texture = self.app.textures.texture_2
        logo_width = 400
        logo_height = 100
        x = (self.app.width - logo_width) // 2
        y = 460  # Correct y position for the logo
        self.logo_button = TexturedButton(
            self.app, x, y, logo_width, logo_height, text=None, on_click=None, shader=self.shader, texture=logo_texture
        )

    def create_main_menu(self):
        center_x = self.app.width // 2
        button_width = 200
        button_height = 60
        start_y = self.app.height // 2 + 40
        button_texture = self.app.textures.texture_4
        self.main_menu_buttons = [
            TexturedButton(
                self.app,
                center_x - button_width // 2,
                start_y,
                button_width,
                button_height,
                "Singleplayer",
                lambda: self.start_game(),
                shader=self.shader,
                texture=button_texture
            ),
            TexturedButton(
                self.app,
                center_x - button_width // 2,
                start_y - 80,
                button_width,
                button_height,
                "Settings",
                lambda: self.open_settings(),
                shader=self.shader,
                texture=button_texture
            ),
            TexturedButton(
                self.app,
                center_x - button_width // 2,
                start_y - 160,
                button_width,
                button_height,
                "Quit to desktop",
                lambda: self.quit_game(),
                shader=self.shader,
                texture=button_texture
            )
        ]

    def create_settings_menu(self):
        center_x = self.app.width // 2
        button_width = 200
        button_height = 50
        start_y = self.app.height // 2 + 20
        button_texture = self.app.textures.texture_4
        self.settings_menu_buttons = [
            TexturedButton(
                self.app,
                center_x - button_width // 2,
                start_y,
                button_width,
                button_height,
                "Graphics",
                lambda: print("Graphics settings..."),
                shader=self.shader,
                texture=button_texture
            ),
            TexturedButton(
                self.app,
                center_x - button_width // 2,
                start_y - 70,
                button_width,
                button_height,
                "Audio",
                lambda: print("Audio settings..."),
                shader=self.shader,
                texture=button_texture
            ),
            TexturedButton(
                self.app,
                center_x - button_width // 2,
                start_y - 140,
                button_width,
                button_height,
                "Back",
                lambda: self.go_back(),
                shader=self.shader,
                texture=button_texture
            )
        ]

    def toggle_inventory(self):
        """Toggle inventory open/closed"""
        if self.app.game_state == "playing":
            self.inventory_open = not self.inventory_open
            print(f"Inventory {'opened' if self.inventory_open else 'closed'}")
            
            # Toggle mouse exclusive mode
            if self.inventory_open:
                self.app.set_exclusive_mouse(False)
            else:
                self.app.set_exclusive_mouse(True)

    def start_game(self):
        print("Starting game...")
        self.app.game_state = "playing"
        self.app.set_exclusive_mouse(True)

    def open_settings(self):
        print("Opening settings...")
        self.app.game_state = "settings"

    def quit_game(self):
        print("Quitting game...")
        self.app.is_running = False

    def go_back(self):
        print("Back to menu...")
        self.app.game_state = "menu"

    def handle_key_press(self, key):
        """Handle keyboard input for inventory"""
        if self.app.game_state == "playing":
            # Check for inventory key (E key)
            if key == self.app.wnd.keys.TAB:  # Use moderngl_window key constant
                self.toggle_inventory()
                return True
        return False

    def render(self, game_state):
        self.ctx.disable(self.ctx.DEPTH_TEST)
        self.ctx.enable(self.ctx.BLEND)
        
        # Render menu/settings UI
        if game_state in ["menu", "settings"]:
            # Draw background
            self.bg_texture.use(location=0)
            self.shader['u_texture'] = 0
            self.shader['u_color'] = (1, 1, 1, 1)
            self.bg_vao.render()
            
            # Draw logo (always at the top)
            self.logo_button.render()
            
            # Draw menu buttons
            buttons = self.main_menu_buttons if game_state == "menu" else self.settings_menu_buttons
            for button in buttons:
                button.render()
        
        # Render in-game UI
        elif game_state == "playing":
            # Always render hotbar when playing
            self.hotbar_texture.use(location=0)
            self.shader['u_texture'] = 0
            self.shader['u_color'] = (1, 1, 1, 0.9)  # Slightly transparent
            self.hotbar_vao.render()
            
            # Render inventory if open
            if self.inventory_open:
                self.inventory_texture.use(location=0)
                self.shader['u_texture'] = 0
                self.shader['u_color'] = (1, 1, 1, 0.95)  # Slightly transparent
                self.inventory_vao.render()
        
        self.ctx.enable(self.ctx.DEPTH_TEST)

    def handle_mouse_press(self, x, y, button):
        y_flipped = self.app.height - y
        
        # Only handle menu button clicks when in menu/settings
        if self.app.game_state in ["menu", "settings"]:
            buttons = (self.main_menu_buttons if self.app.game_state == "menu" else self.settings_menu_buttons)
            for btn in buttons:
                if btn.on_mouse_press(x, y_flipped, button):
                    return True
        
        return False

    def handle_mouse_release(self, x, y, button):
        y_flipped = self.app.height - y
        
        # Only handle menu button releases when in menu/settings
        if self.app.game_state in ["menu", "settings"]:
            buttons = (self.main_menu_buttons if self.app.game_state == "menu" else self.settings_menu_buttons)
            for btn in buttons:
                btn.on_mouse_release(x, y_flipped, button)
        
        return False