import numpy as np
from PIL import Image, ImageDraw, ImageFont

class TexturedButton:
    def __init__(self, app, x, y, width, height, text="", on_click=None, shader=None, texture=None):
        self.app = app
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.text = text
        self.on_click = on_click
        self.pressed = False
        self.hovered = False
        # Use provided texture or default to texture_0 (button background)
        self.texture = texture if texture is not None else self.app.textures.texture_0
        self.shader = shader
        self.text_texture = self.create_text_texture(text) if text else None
        self.setup_geometry()

    def setup_geometry(self):
        screen_w = self.app.width
        screen_h = self.app.height
        x1 = (self.x / screen_w) * 2 - 1
        y1 = (self.y / screen_h) * 2 - 1
        x2 = ((self.x + self.width) / screen_w) * 2 - 1
        y2 = ((self.y + self.height) / screen_h) * 2 - 1
        vertices = np.array([
            x1, y1,  0.0, 0.0,
            x2, y1,  1.0, 0.0,
            x2, y2,  1.0, 1.0,
            x1, y1,  0.0, 0.0,
            x2, y2,  1.0, 1.0,
            x1, y2,  0.0, 1.0
        ], dtype=np.float32)
        self.vbo = self.app.ctx.buffer(vertices.tobytes())
        self.vao = self.app.ctx.vertex_array(
            self.shader,
            [ (self.vbo, '2f 2f', 'in_position', 'in_texcoord') ]
        )

    def create_text_texture(self, text):
        # Render text to a PIL image, then upload as a ModernGL texture
        font_size = 18
        font_path = 'assets/main.ttf'
        img = Image.new('RGBA', (self.width, self.height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        try:
            font = ImageFont.truetype(font_path, font_size)
        except Exception:
            font = ImageFont.load_default()
        # Use getbbox for FreeTypeFont in Pillow >=10
        try:
            bbox = font.getbbox(text)
        except AttributeError:
            # Fallback for older Pillow or other font types
            bbox = draw.textbbox((0, 0), text, font=font)
        w = bbox[2] - bbox[0]
        h = bbox[3] - bbox[1]
        draw.text(((self.width-w)//2, (self.height-h)//2), text, font=font, fill=(255,255,255,255))
        img = img.transpose(Image.FLIP_TOP_BOTTOM)  # Flip vertically for OpenGL
        tex = self.app.ctx.texture(img.size, 4, img.tobytes())
        tex.build_mipmaps()
        tex.filter = (self.app.ctx.NEAREST, self.app.ctx.NEAREST)
        return tex

    def get_color(self):
        if self.pressed:
            return (0.7, 0.7, 0.7, 1.0)
        elif self.hovered:
            return (0.9, 0.9, 0.9, 1.0)
        else:
            return (1.0, 1.0, 1.0, 1.0)

    def contains_point(self, x, y):
        contains = (self.x <= x <= self.x + self.width and self.y <= y <= self.y + self.height)
        return contains

    def render(self):
        # Render button background
        self.texture.use(location=0)
        self.shader['u_texture'] = 0
        self.shader['u_color'] = self.get_color()
        self.vao.render()
        # Render text as overlay
        if self.text_texture:
            self.text_texture.use(location=0)
            self.shader['u_texture'] = 0
            self.shader['u_color'] = (1, 1, 1, 1)
            self.vao.render()

    def on_mouse_press(self, x, y, button):
        if self.contains_point(x, y):
            self.pressed = True
            return True
        return False

    def on_mouse_release(self, x, y, button):
        if self.pressed and self.contains_point(x, y):
            self.pressed = False
            if self.on_click:
                self.on_click()
            return True
        self.pressed = False
        return False