import moderngl as mgl
import numpy as np

class InventoryManager:
    def __init__(self, app):
        self.app = app
        self.ctx = app.ctx
        self.is_inventory_open = False
        self.selected_slot = 0
        self.num_hotbar_slots = 9
        
        # Setup shaders and geometry
        self.setup_shader()
        self.setup_inventory()
        self.setup_hotbar()
    
    def setup_shader(self):
        vertex_shader = '''
            #version 330 core
            in vec2 in_position;
            in vec2 in_texcoord;
            out vec2 uv;
            
            void main() {
                gl_Position = vec4(in_position, 0.0, 1.0);
                uv = in_texcoord;
            }
        '''
        
        fragment_shader = '''
            #version 330 core
            uniform sampler2D u_texture;
            uniform vec4 u_color;
            in vec2 uv;
            out vec4 fragColor;
            
            void main() {
                vec4 tex_color = texture(u_texture, uv);
                fragColor = tex_color * u_color;
            }
        '''
        
        self.shader = self.ctx.program(
            vertex_shader=vertex_shader,
            fragment_shader=fragment_shader
        )
    
    def setup_inventory(self):
        # Inventory background geometry (27 slots, 9x3 grid)
        rows = 3
        cols = 9
        slot_size = 50
        padding = 4
        
        inventory_width = cols * (slot_size + padding) - padding
        inventory_height = rows * (slot_size + padding) - padding
        
        # Center the inventory
        start_x = (self.app.width - inventory_width) / 2
        start_y = (self.app.height - inventory_height) / 2
        
        self.inventory_slots = []
        
        for row in range(rows):
            for col in range(cols):
                x = start_x + col * (slot_size + padding)
                y = start_y + row * (slot_size + padding)
                
                self.inventory_slots.append(
                    self.create_slot(x, y, slot_size, slot_size)
                )
    
    def setup_hotbar(self):
        # Hotbar geometry (9 slots)
        slot_size = 50
        padding = 4
        
        hotbar_width = self.num_hotbar_slots * (slot_size + padding) - padding
        
        # Center the hotbar at bottom of screen
        start_x = (self.app.width - hotbar_width) / 2
        start_y = 20  # Offset from bottom
        
        self.hotbar_slots = []
        
        for i in range(self.num_hotbar_slots):
            x = start_x + i * (slot_size + padding)
            self.hotbar_slots.append(
                self.create_slot(x, start_y, slot_size, slot_size)
            )
        
        # Create selection highlight
        highlight_size = slot_size + 4
        self.hotbar_highlights = []
        
        for i in range(self.num_hotbar_slots):
            x = start_x + i * (slot_size + padding) - 2
            y = start_y - 2
            self.hotbar_highlights.append(
                self.create_slot(x, y, highlight_size, highlight_size)
            )
    
    def create_slot(self, x, y, width, height):
        # Convert to NDC coordinates
        x1 = (x / self.app.width) * 2 - 1
        y1 = (y / self.app.height) * 2 - 1
        x2 = ((x + width) / self.app.width) * 2 - 1
        y2 = ((y + height) / self.app.height) * 2 - 1
        
        # Vertices with texture coordinates
        vertices = np.array([
            # pos    # tex coords
            x1, y1,  0.0, 0.0,  # Bottom left
            x2, y1,  1.0, 0.0,  # Bottom right
            x2, y2,  1.0, 1.0,  # Top right
            x1, y1,  0.0, 0.0,  # Bottom left
            x2, y2,  1.0, 1.0,  # Top right
            x1, y2,  0.0, 1.0   # Top left
        ], dtype=np.float32)
        
        vbo = self.ctx.buffer(vertices.tobytes())
        vao = self.ctx.vertex_array(
            self.shader,
            [
                (vbo, '2f 2f', 'in_position', 'in_texcoord')
            ]
        )
        
        return {
            'vao': vao,
            'x': x,
            'y': y,
            'width': width,
            'height': height
        }
    
    def render(self):
        self.ctx.disable(mgl.DEPTH_TEST)
        
        # Always render hotbar
        self.render_hotbar()
        
        # Render full inventory if open
        if self.is_inventory_open:
            self.render_inventory()
        
        self.ctx.enable(mgl.DEPTH_TEST)
    
    def render_hotbar(self):
        # Set slot texture and color
        self.app.textures.texture_0.use(location=0)
        self.shader['u_texture'] = 0
        
        # Render highlight under selected slot
        self.shader['u_color'] = (1.0, 1.0, 0.0, 0.3)  # Yellow highlight
        self.hotbar_highlights[self.selected_slot]['vao'].render()
        
        # Render all slots
        self.shader['u_color'] = (1.0, 1.0, 1.0, 0.8)
        for slot in self.hotbar_slots:
            slot['vao'].render()
    
    def render_inventory(self):
        # Render inventory background
        self.shader['u_color'] = (0.0, 0.0, 0.0, 0.5)  # Semi-transparent black
        
        # Set slot texture and color
        self.app.textures.texture_0.use(location=0)
        self.shader['u_texture'] = 0
        self.shader['u_color'] = (1.0, 1.0, 1.0, 0.8)
        
        # Render all inventory slots
        for slot in self.inventory_slots:
            slot['vao'].render()
    
    def update(self):
        # Handle scroll wheel for hotbar selection
        pass
    
    def toggle_inventory(self):
        self.is_inventory_open = not self.is_inventory_open
        if self.is_inventory_open:
            self.app.set_exclusive_mouse(False)
        else:
            self.app.set_exclusive_mouse(True)
    
    def close_inventory(self):
        if self.is_inventory_open:
            self.is_inventory_open = False
            self.app.set_exclusive_mouse(True)
    
    def handle_mouse_press(self, x, y, button):
        # Handle inventory interaction
        if not self.is_inventory_open:
            return False
        
        # Check for clicks on inventory slots
        for slot in self.inventory_slots:
            if self.point_in_slot(x, y, slot):
                print(f"Clicked inventory slot at ({slot['x']}, {slot['y']})")
                return True
        return False
    
    def handle_mouse_release(self, x, y, button):
        pass
    
    def point_in_slot(self, x, y, slot):
        return (slot['x'] <= x <= slot['x'] + slot['width'] and 
                slot['y'] <= y <= slot['y'] + slot['height'])