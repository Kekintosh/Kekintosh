from PIL import Image
import moderngl as mgl

class Textures:
    def __init__(self, app):
        self.app = app
        self.ctx = app.ctx
        # load textures
        self.texture_0 = self.load('frame.png')
        self.texture_1 = self.load('water.png')
        self.texture_2 = self.load('game_logo.png')
        self.texture_3 = self.load('0.jpg')
        self.texture_4 = self.load('button_bg.png')
        self.texture_5 = self.load('button_bg_hover.png')
        self.texture_6 = self.load('inventory.png')
        self.texture_7 = self.load('inventory_window.png')
        self.texture_array_0 = self.load('tex_array_0.png', is_tex_array=True)
        # assign texture unit
        self.texture_0.use(location=0)
        self.texture_array_0.use(location=1)
        self.texture_1.use(location=2)
        self.texture_2.use(location=3)
    def load(self, file_name, is_tex_array=False):
        if not file_name == 'tex_array_0.png':
            image = Image.open(f'assets/{file_name}').convert('RGBA').transpose(Image.FLIP_TOP_BOTTOM)
        else:
            image = Image.open(f'assets/{file_name}').convert('RGBA').transpose(Image.FLIP_LEFT_RIGHT)
            
          
        if is_tex_array:
            width, height = image.size
            num_layers = 3 * height // width  # 3 textures per layer
            if image.mode != 'RGBA':
                image = image.convert('RGBA')
            texture = self.app.ctx.texture_array(
                size=(width, height // num_layers, num_layers),
                components=4,
                data=image.tobytes()
            )
        else:
            if image.mode != 'RGBA':
                image = image.convert('RGBA')
            texture = self.ctx.texture(
                size=image.size,
                components=4,
                data=image.tobytes()
            )
        texture.anisotropy = 32.0
        texture.build_mipmaps()
        texture.filter = (mgl.NEAREST, mgl.NEAREST)
        return texture
